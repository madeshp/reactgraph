import Cytoscape from "cytoscape";
import COSEBilkent from "cytoscape-cose-bilkent";
import CytoscapeComponent from "react-cytoscapejs";
Cytoscape.use(COSEBilkent);
export default CytoscapeComponent;
